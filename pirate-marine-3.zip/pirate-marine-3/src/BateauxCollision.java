import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class BateauxCollision extends JPanel implements ActionListener {
    private static final int LARGEUR_FENETRE = 1000;
    private static final int HAUTEUR_FENETRE = 600;
    private final int LARGEUR_BATEAU = 50;
    private final int HAUTEUR_BATEAU = 50;
    private static final int DELAI = 10;
    private static int VITESSE_MARINE = 1;
    private static int VITESSE_PIRATES = 1;
    private static final long EXPLOSION_DUREE = 1000;

    private final List<Bateau> bateauxPirate;
    private final List<Bateau> bateauxMarine;
    private final Image explosionImage;
    private boolean explosionActive = false;
    private int explosionX = 0;
    private int explosionY = 0;
    private long explosionDebut = 0;

    private final JSlider sliderVitesseMarine;
    private final JSlider sliderVitessePirates;

    public BateauxCollision() {
        javax.swing.Timer timer = new javax.swing.Timer(DELAI, this);
        timer.start();

        bateauxPirate = new ArrayList<>();
        bateauxMarine = new ArrayList<>();

        ImageIcon bateauPIcon = new ImageIcon("bateauPimage.png");
        Image bateauPimage = bateauPIcon.getImage();

        ImageIcon bateauMIcon = new ImageIcon("bateauMimage.png");
        Image bateauMimage = bateauMIcon.getImage();

        ImageIcon explosionIcon = new ImageIcon("explosion.png");
        explosionImage = explosionIcon.getImage();

        Random random = new Random();

        int NOMBRE_BATEAUX_PIRATE = 15;
        for (int i = 0; i < NOMBRE_BATEAUX_PIRATE; i++) {
            bateauxPirate.add(new Bateau(random.nextInt(LARGEUR_FENETRE - LARGEUR_BATEAU), random.nextInt(HAUTEUR_FENETRE - HAUTEUR_BATEAU), bateauPimage));
        }

        int NOMBRE_BATEAUX_MARINE = 15;
        for (int i = 0; i < NOMBRE_BATEAUX_MARINE; i++) {
            bateauxMarine.add(new Bateau(random.nextInt(LARGEUR_FENETRE - LARGEUR_BATEAU), random.nextInt(HAUTEUR_FENETRE - HAUTEUR_BATEAU), bateauMimage));
        }

        Color couleurFond = new Color(30, 144, 255);
        setBackground(couleurFond);
        setPreferredSize(new Dimension(LARGEUR_FENETRE, HAUTEUR_FENETRE));

        sliderVitesseMarine = new JSlider(JSlider.HORIZONTAL, 1, 5, VITESSE_MARINE);
        sliderVitessePirates = new JSlider(JSlider.HORIZONTAL, 1, 5, VITESSE_PIRATES);

        sliderVitesseMarine.setMajorTickSpacing(1);
        sliderVitesseMarine.setPaintTicks(true);
        sliderVitesseMarine.setPaintLabels(true);

        sliderVitessePirates.setMajorTickSpacing(1);
        sliderVitessePirates.setPaintTicks(true);
        sliderVitessePirates.setPaintLabels(true);

        sliderVitesseMarine.addChangeListener(e -> VITESSE_MARINE = sliderVitesseMarine.getValue());

        sliderVitessePirates.addChangeListener(e -> VITESSE_PIRATES = sliderVitessePirates.getValue());

        JPanel panelSliders = new JPanel(new GridLayout(2, 2));
        panelSliders.add(new JLabel("Vitesse Marine:"));
        panelSliders.add(sliderVitesseMarine);
        panelSliders.add(new JLabel("Vitesse Pirates:"));
        panelSliders.add(sliderVitessePirates);

        add(panelSliders, BorderLayout.SOUTH);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (Bateau bateau : bateauxPirate) {
            bateau.dessiner(g);
        }

        for (Bateau bateau : bateauxMarine) {
            bateau.dessiner(g);
        }

        if (explosionActive) {
            long tempsActuel = System.currentTimeMillis();
            long tempsDepuisExplosion = tempsActuel - explosionDebut;

            if (tempsDepuisExplosion < EXPLOSION_DUREE) {
                g.drawImage(explosionImage, explosionX, explosionY, LARGEUR_BATEAU, HAUTEUR_BATEAU, null);
            } else {
                explosionActive = false;
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Random random = new Random();

        for (Bateau bateau : bateauxPirate) {
            Bateau bateauMarinPlusProche = trouverBateauPlusProche(bateau, bateauxMarine);
            if (bateauMarinPlusProche != null) {
                bateau.deplacerVers(bateauMarinPlusProche, bateauxPirate);
            }
        }

        for (Bateau marine : bateauxMarine) {
            Bateau bateauPiratePlusProche = trouverBateauPlusProche(marine, bateauxPirate);
            if (bateauPiratePlusProche != null) {
                marine.deplacerVers(bateauPiratePlusProche, bateauxMarine);
            }
        }

        Iterator<Bateau> iteratorPirate = bateauxPirate.iterator();
        while (iteratorPirate.hasNext()) {
            Bateau pirate = iteratorPirate.next();
            Iterator<Bateau> iteratorMarine = bateauxMarine.iterator();
            while (iteratorMarine.hasNext()) {
                Bateau marine = iteratorMarine.next();
                if (pirate.seToucheAvec(marine)) {
                    if (random.nextBoolean()) {
                        explosionActive = true;
                        explosionX = pirate.x + (LARGEUR_BATEAU - LARGEUR_BATEAU / 2);
                        explosionY = pirate.y + (HAUTEUR_BATEAU - HAUTEUR_BATEAU / 2);
                        explosionDebut = System.currentTimeMillis();
                        iteratorPirate.remove();
                    } else {
                        iteratorMarine.remove();
                        explosionActive = true;
                        explosionX = marine.x + (LARGEUR_BATEAU - LARGEUR_BATEAU / 2);
                        explosionY = marine.y + (HAUTEUR_BATEAU - HAUTEUR_BATEAU / 2);
                        explosionDebut = System.currentTimeMillis();
                    }
                }
            }
        }

        repaint();
    }


    private class Bateau {
        private int x, y;
        private final Image image;

        public Bateau(int x, int y, Image image) {
            this.x = x;
            this.y = y;
            this.image = image;
        }

        public void dessiner(Graphics g) {
            g.drawImage(image, x, y, LARGEUR_BATEAU, HAUTEUR_BATEAU, null);
        }

        public void deplacer(int dx, int dy) {
            x += dx;
            y += dy;

            if (x < 0) x = 0;
            if (x > LARGEUR_FENETRE - LARGEUR_BATEAU) x = LARGEUR_FENETRE - LARGEUR_BATEAU;
            if (y < 0) y = 0;
            if (y > HAUTEUR_FENETRE - HAUTEUR_BATEAU) y = HAUTEUR_FENETRE - HAUTEUR_BATEAU;
        }

        public void deplacerVers(Bateau destination, List<Bateau> obstacles) {
            Queue<Noeud> filePrioritaire = new PriorityQueue<>();
            List<Noeud> exploredNodes = new ArrayList<>();

            Noeud initialNode = new Noeud(this.x, this.y);
            Noeud goalNode = new Noeud(destination.x, destination.y);

            filePrioritaire.add(initialNode);

            while (!filePrioritaire.isEmpty()) {
                Noeud current = filePrioritaire.poll();

                if (current.equals(goalNode)) {
                    List<Noeud> path = new ArrayList<>();
                    while (current != null) {
                        path.add(current);
                        current = current.parent;
                    }
                    Collections.reverse(path);

                    if (path.size() > 1) {
                        Noeud nextNode = path.get(1);
                        int dx = nextNode.x - this.x;
                        int dy = nextNode.y - this.y;

                        int distance = (int) Math.sqrt(dx * dx + dy * dy);
                        if (distance > VITESSE_MARINE) {
                            dx = (dx * VITESSE_MARINE) / distance;
                            dy = (dy * VITESSE_MARINE) / distance;
                        }

                        boolean collision = false;
                        for (Bateau obstacle : obstacles) {
                            if (obstacle != this && obstacle.seToucheAvec(this.x + dx, this.y + dy)) {
                                collision = true;
                                break;
                            }
                        }

                        if (!collision) {
                            this.deplacer(dx, dy);
                        }
                    }

                    break;
                }

                exploredNodes.add(current);

                for (Noeud neighbor : current.getNeighbors()) {
                    if (!exploredNodes.contains(neighbor) && !filePrioritaire.contains(neighbor)) {
                        neighbor.parent = current;
                        filePrioritaire.add(neighbor);
                    }
                }
            }
        }

        public boolean seToucheAvec(Bateau autreBateau) {
            return x + LARGEUR_BATEAU >= autreBateau.x && x <= autreBateau.x + LARGEUR_BATEAU
                    && y + HAUTEUR_BATEAU >= autreBateau.y && y <= autreBateau.y + HAUTEUR_BATEAU;
        }

        public boolean seToucheAvec(int newX, int newY) {
            return newX + LARGEUR_BATEAU >= x && newX <= x + LARGEUR_BATEAU
                    && newY + HAUTEUR_BATEAU >= y && newY <= y + HAUTEUR_BATEAU;
        }
    }

    private Bateau trouverBateauPlusProche(Bateau bateau, List<Bateau> listeBateaux) {
        Bateau plusProche = null;
        double distanceMin = Double.MAX_VALUE;

        for (Bateau autreBateau : listeBateaux) {
            if (autreBateau != bateau) {
                // Utilisation de l'algorithme A* pour calculer la distance heuristique
                double distanceHeuristique = Math.sqrt(Math.pow(bateau.x - autreBateau.x, 2) + Math.pow(bateau.y - autreBateau.y, 2));

                // Comparaison avec la distance minimale actuelle
                if (distanceHeuristique < distanceMin) {
                    distanceMin = distanceHeuristique;
                    plusProche = autreBateau;
                }
            }
        }

        return plusProche;
    }

    private static class Noeud implements Comparable<Noeud> {
        private final int x;
        private final int y;
        private Noeud parent;

        public Noeud(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public List<Noeud> getNeighbors() {
            List<Noeud> neighbors = new ArrayList<>();
            neighbors.add(new Noeud(x + 1, y));
            neighbors.add(new Noeud(x - 1, y));
            neighbors.add(new Noeud(x, y + 1));
            neighbors.add(new Noeud(x, y - 1));
            return neighbors;
        }

        @Override
        public int compareTo(Noeud autre) {
            return Integer.compare(this.x + this.y, autre.x + autre.y);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            Noeud noeud = (Noeud) obj;
            return x == noeud.x && y == noeud.y;
        }

        @Override
        public int hashCode() {
            return Objects.hash(x, y);
        }
    }
}
